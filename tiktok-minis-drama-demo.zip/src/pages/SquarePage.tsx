import { useCallback, useEffect, useMemo, useState } from 'react';
import { BottomNav } from '../components/BottomNav';
import { DramaCard } from '../components/DramaCard';
import { mapDrama } from '../api/adapters';
import { getDramaDetail } from '../api/client';
import { useDramaList } from '../hooks/useDramaApi';
import { preloadDramaEpisode } from '../plugins/minis-player';
import { preloadTheaterPageCode } from '../router/lazy-pages';
import type { DramaSummary } from '../types/drama';

const categories: Array<DramaSummary['category']> = ['Popular', 'Original+', 'Female', 'Male', 'New'];

export function SquarePage() {
  const [category, setCategory] = useState<DramaSummary['category']>('Popular');
  const { data: dramas = [], loading, error } = useDramaList();
  const list = useMemo(() => {
    const exact = dramas.filter((drama) => drama.category === category);
    return exact.length >= 3 ? exact : [...exact, ...dramas.filter((item) => !exact.includes(item))];
  }, [category, dramas]);
  const featuredDramas = useMemo(() => {
    const primaryCards = list.slice(0, 2);
    return [...primaryCards, ...primaryCards];
  }, [list]);
  const preloadOnIntent = useCallback((drama: DramaSummary) => {
    if (drama.preloadEpisode) {
      void preloadDramaEpisode(drama, drama.preloadEpisode);
    }
    void preloadTheaterPageCode();
  }, []);

  useEffect(() => {
    const firstDrama = dramas[0];
    if (!firstDrama) return;

    // Start media preload as soon as the discovery response is rendered. This
    // runs while the user browses the square; theater playback never waits for
    // a new preload task to be created.
    if (firstDrama.preloadEpisode) {
      void preloadDramaEpisode(firstDrama, firstDrama.preloadEpisode);
      void preloadTheaterPageCode();
      return;
    }

    // Backward-compatible fallback for list APIs that do not expose a preload
    // episode yet. New integrations should return preload_episode in the list.
    let active = true;
    getDramaDetail(firstDrama.id)
      .then(({ data }) => {
        if (!active) return;
        const drama = mapDrama(data.drama);
        const firstEpisode = drama.episodes[0];
        if (firstEpisode) return preloadDramaEpisode(drama, firstEpisode);
      })
      .catch((cause) => console.warn('[preload] Failed to load the first drama.', cause));
    void preloadTheaterPageCode();
    return () => {
      active = false;
    };
  }, [dramas]);

  if (loading) return <main className="app-shell square-page"><div className="page-state">Loading dramas…</div></main>;
  if (error || !dramas.length) return <main className="app-shell square-page"><div className="page-state">{error ?? 'No dramas found.'}</div></main>;

  return (
    <main className="app-shell square-page">
      <header className="square-header">
        <div className="category-tabs" role="tablist">
          {categories.map((item) => <button key={item} role="tab" aria-selected={category === item} onClick={() => setCategory(item)}>{item}</button>)}
        </div>
      </header>

      <section className="square-content">
        <DramaCard
          drama={list[0]}
          featured
          onPreloadIntent={() => preloadOnIntent(list[0])}
        />
        <h2>Featured</h2>
        <div className="poster-rail">{featuredDramas.map((drama, index) => (
          <DramaCard
            key={`${drama.id}-${index}`}
            drama={drama}
            onPreloadIntent={() => preloadOnIntent(drama)}
          />
        ))}</div>
        <h2>Trending now</h2>
        <div className="poster-rail">{dramas.slice(0, 4).map((drama) => (
          <DramaCard
            key={drama.id}
            drama={drama}
            onPreloadIntent={() => preloadOnIntent(drama)}
          />
        ))}</div>
      </section>
      <BottomNav />
    </main>
  );
}
