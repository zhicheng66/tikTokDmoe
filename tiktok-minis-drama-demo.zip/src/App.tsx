import { Suspense } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { SquarePage } from './pages/SquarePage';
import { LazyTheaterPage } from './router/lazy-pages';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/playlet/square" replace />} />
        <Route path="/playlet/square" element={<SquarePage />} />
        <Route
          path="/playlet/theater"
          element={(
            <Suspense fallback={<main className="app-shell theater-page" />}>
              <LazyTheaterPage />
            </Suspense>
          )}
        />
        <Route path="*" element={<Navigate to="/playlet/square" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
