/** Raw wire models. Keep API field names unchanged at this boundary. */
export interface EpisodeDTO {
  episode_id: string;
  album_id: string;
  episode_number: number;
  title: string;
  description: string;
  vid: string;
  play_auth_token?: string;
  poster_url?: string;
}

export interface DramaDTO {
  drama_id: string;
  title: string;
  subtitle: string;
  category: 'Popular' | 'Original+' | 'Female' | 'Male' | 'New';
  cover_url: string;
  episode_count: number;
  episodes: EpisodeDTO[];
}

/**
 * List responses may include the episode most likely to be opened next. This
 * lets the discovery page start MANUAL preload without another detail request.
 */
export interface DramaSummaryDTO extends Omit<DramaDTO, 'episodes'> {
  preload_episode?: EpisodeDTO;
}

export interface DramaListResponse {
  data: { dramas: DramaSummaryDTO[] };
}

export interface DramaDetailResponse {
  data: { drama: DramaDTO };
}
