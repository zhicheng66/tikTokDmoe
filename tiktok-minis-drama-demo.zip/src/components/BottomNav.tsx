import { BookmarkIcon, HomeIcon, PlayIcon, UserIcon } from './Icons';

const items = [
  { label: 'Home', Icon: HomeIcon, active: true },
  { label: 'For you', Icon: PlayIcon },
  { label: 'My List', Icon: BookmarkIcon },
  { label: 'Profile', Icon: UserIcon },
];

export function BottomNav() {
  return (
    <nav className="bottom-nav" aria-label="Primary navigation">
      {items.map(({ label, Icon, active }) => (
        <button key={label} className={active ? 'nav-item is-active' : 'nav-item'} disabled={!active} aria-current={active ? 'page' : undefined}>
          <Icon />
          <span>{label}</span>
        </button>
      ))}
    </nav>
  );
}
