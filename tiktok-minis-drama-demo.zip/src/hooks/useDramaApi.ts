import { useEffect, useState } from 'react';
import { mapDrama, mapDramaSummary } from '../api/adapters';
import { getDramaDetail, getDramaList } from '../api/client';
import type { Drama, DramaSummary } from '../types/drama';

interface ApiState<T> {
  data?: T;
  loading: boolean;
  error?: string;
}

export function useDramaList(): ApiState<DramaSummary[]> {
  const [state, setState] = useState<ApiState<DramaSummary[]>>({ loading: true });

  useEffect(() => {
    let active = true;
    getDramaList()
      .then(({ data }) => {
        if (active) setState({ data: data.dramas.map(mapDramaSummary), loading: false });
      })
      .catch((error: unknown) => {
        if (active) setState({ loading: false, error: error instanceof Error ? error.message : String(error) });
      });
    return () => {
      active = false;
    };
  }, []);

  return state;
}

export function useDramaDetail(dramaId: string): ApiState<Drama> {
  const [state, setState] = useState<ApiState<Drama>>({ loading: true });

  useEffect(() => {
    let active = true;
    setState({ loading: true });
    getDramaDetail(dramaId)
      .then(({ data }) => {
        if (active) setState({ data: mapDrama(data.drama), loading: false });
      })
      .catch((error: unknown) => {
        if (active) setState({ loading: false, error: error instanceof Error ? error.message : String(error) });
      });
    return () => {
      active = false;
    };
  }, [dramaId]);

  return state;
}
