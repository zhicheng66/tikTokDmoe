import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5177,
    strictPort: true,
    cors: {
      origin: true,
    },
  },
  preview: {
    host: true,
    port: 4177,
    cors: true,
  },
  build: {
    target: ['es2020', 'safari13'],
  },
});
