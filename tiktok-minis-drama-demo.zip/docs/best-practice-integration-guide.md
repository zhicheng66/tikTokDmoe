# TikTok Minis 短剧 H5 最佳实践 Demo 使用手册

> 适用工程：`tiktok-minis-drama-demo`  
> 适用读者：需要在 TikTok Minis WebView 中接入短剧播放的前端、客户端和服务端开发者  
> 核心原则：通过 Minis Script 获取 Player，不安装或直接引用 `@volcengine/veplayer`

## 1. Demo 介绍

`tiktok-minis-drama-demo` 是一个移动端优先的 React 短剧 H5 示例，包含：

- 广场页：分类、主推荐、横向剧集列表和底部导航。
- 播放页：沉浸式短剧播放、上下滑动切集、选集面板、播放控制条。
- 单 Player 实例：初次进入创建一次 Player，正常切集使用 `playNext()`。
- 广场预热：列表返回后立即使用 MANUAL 场景预热可能播放的首集。
- 播放页预加载：首帧出现后切换为 AUTO 场景，自动预加载前后集。
- WebView 生命周期：页面进入后台时暂停，回到前台时按原播放状态恢复。
- 切集事务：只有 `playNext()` 成功后才提交集数 UI，失败时保留当前集。
- 自然播放结束：自动进入下一集，最后一集播放完成后给出结束提示。
- 画面适配：默认 `contain`，保证横屏和竖屏视频不被裁切。
- 交互能力：暂停/继续、进度拖动、长按 2 倍速及锁定、点赞等演示 UI。

Demo 的主要路由：

| 页面 | 路由 |
| --- | --- |
| 广场页 | `/playlet/square` |
| 播放页 | `/playlet/theater?id=<dramaId>` |

## 2. 设计目标

这个工程不是把所有代码塞进一个页面，而是把播放器接入拆成三个边界：

```mermaid
flowchart LR
    API["业务 API<br/>list/detail"] --> Adapter["数据适配层<br/>snake_case → domain"]
    Adapter --> Page["React 页面与交互"]
    Page --> Hook["播放器生命周期 Hook"]
    Hook --> Plugin["可复制的 minis-player 插件"]
    Plugin --> SDK["window.TTMinis.getPlayer()"]
```

### 2.1 可复制

`src/plugins/minis-player/` 不依赖 React 和 Demo 页面，可以作为一个文件夹复制到客户自己的
TypeScript 工程。

### 2.2 配置一致

初次播放、`playNext()` 和预加载必须使用相同的：

- `vid`
- `albumId`
- `episodeId`
- `playAuthToken`（如果业务需要）
- `defaultDefinition`

任何一个字段不一致，都可能导致预加载或媒体信息缓存无法命中。

### 2.3 预加载不阻塞播放

预加载是优化能力，不是播放前置条件：

- 广场尽早开始预热。
- 播放页不人为等待预热下载。
- 预热失败时仍然创建 Player，走正常播放链路。
- 不添加 1.2 秒之类的人为 sleep。

## 3. 快速运行

### 3.1 环境要求

- Node.js 18 或更高版本
- npm
- 可访问 TikTok Minis SDK 和视频 CDN 的网络

### 3.2 安装与启动

```bash
npm install
npm run dev
```

默认访问：

```text
http://localhost:5177/playlet/square
```

注意：本工程端口是 `5177`，不是 Vite 常见的 `5173`。如果端口被占用，应先停止占用进程，
不要在 `minis.config.json`、Vite 和实际访问地址之间使用不同端口。

### 3.3 Minis 容器调试

保持 Web 服务运行，再启动：

```bash
npm run minis:debug
```

`minis.config.json` 中的端口必须与 Vite 一致。

## 4. 构建与检查

完整构建：

```bash
npm run build
npm run check:minis:output
```

常用命令：

| 命令 | 用途 |
| --- | --- |
| `npm run typecheck` | TypeScript 类型检查 |
| `npm run build:web` | 只构建普通 Web 产物 |
| `npm run build:minis` | 构建 Minis 产物 |
| `npm run build:minis:sandbox` | 构建 Minis Sandbox 产物 |
| `npm run check:minis:local` | 检查本地 Minis 配置 |
| `npm run check:minis:output` | 检查最终 Minis 产物 |

最终 `dist/` 应包含：

- `index.html`
- `assets/`
- `posters/`
- `minis.config.json`
- `minis.manifest.json`

## 5. 工程结构

```text
src/
├── api/
│   ├── types.ts              # 服务端原始 DTO
│   ├── client.ts             # List/Detail 请求与 Mock 开关
│   ├── mock-data.ts          # 本地模拟数据
│   └── adapters.ts           # DTO → 页面/播放器模型
├── plugins/minis-player/
│   ├── config.ts             # 清晰度、预加载、缓存策略
│   ├── types.ts              # 可复制的公共类型
│   ├── sdk.ts                # TTMinis.getPlayer() 与构造器缓存
│   ├── playback-config.ts    # 播放身份和 Player 配置
│   ├── playback.ts           # 创建 Player 与 playNext()
│   ├── preload.ts            # prepare、MANUAL、AUTO 预加载
│   └── index.ts              # 插件统一导出
├── hooks/
│   ├── useDramaApi.ts        # React 数据请求状态
│   └── useMinisPlayer.ts     # Player 生命周期与切集事务
├── pages/
│   ├── SquarePage.tsx        # 广场页
│   └── TheaterPage.tsx       # 播放页和滑动/倍速交互
├── router/lazy-pages.ts      # 播放页拆包与广场预加载代码
├── types/drama.ts            # 业务领域模型
└── main.tsx                  # 提前准备 Player 预加载能力
```

## 6. 两种参考集成方式

### 6.1 方式 A：参考完整 Demo

适合需要同时参考广场、播放页、手势和选集 UI 的团队。

建议依次替换：

1. `index.html` 和 `minis.config.json` 中的客户配置。
2. `src/api/` 下的数据请求。
3. `src/api/adapters.ts` 中的字段映射。
4. `src/pages/` 下的业务 UI。
5. 保留 `plugins/minis-player/` 和 `useMinisPlayer.ts` 的核心生命周期。

### 6.2 方式 B：只复制播放器插件

适合客户已经有自己的 React/Vue/原生 TypeScript H5 工程。

复制整个目录：

```text
src/plugins/minis-player/
```

业务工程只从 `index.ts` 导入公开能力，不要跨文件引用插件内部实现：

```ts
import {
  createMinisDramaPlayer,
  playNextEpisode,
  prepareMinisDramaPreload,
  preloadDramaEpisode,
  setupDramaAutoPreload,
} from './minis-player';
```

React 工程还可以参考复制：

```text
src/hooks/useMinisPlayer.ts
```

页面 UI 不需要与 Demo 一致，只要为 Player 提供一个稳定的 DOM 容器即可。

## 7. 引入 Minis SDK

在 HTML 中引入平台提供的 Minis SDK，并初始化：

```html
<script
  id="minis-sdk"
  src="https://connect.tiktok-minis.com/test/sdk-07202011.js"
></script>
<script>
  window.TTMinis.init({ clientKey: '<YOUR_CLIENT_KEY>' });
</script>
```

生产接入注意事项：

1. SDK 地址和版本以 Minis 平台发布要求为准；示例中的 `/test/` 地址不能未经确认直接用于
   正式生产。
2. `index.html` 的 `clientKey` 必须与 `minis.config.json` 完全一致。
3. 不要再安装 `@volcengine/veplayer`，避免同一页面出现两个 Player 版本。
4. 不要读取 Player 私有字段来判断能力，优先使用公开方法和事件。
5. 不要把 PPE Header、内部环境名、内部鉴权信息写进客户侧插件。

工程通过以下方法获取并缓存 Player 构造器：

```ts
const Player = await window.TTMinis.getPlayer('byteplus');
```

实际代码位于 `src/plugins/minis-player/sdk.ts`。

## 8. 数据接口契约

### 8.1 广场列表接口

推荐返回用于广场展示的剧目摘要，并为每个剧目提供一个可选的 `preload_episode`。

```json
{
  "data": {
    "dramas": [
      {
        "drama_id": "drama-1001",
        "title": "Example Drama",
        "subtitle": "Example subtitle",
        "category": "Popular",
        "cover_url": "https://cdn.example.com/drama-1001.jpg",
        "episode_count": 60,
        "preload_episode": {
          "episode_id": "episode-1001-1",
          "album_id": "album-1001",
          "episode_number": 1,
          "title": "Episode 1",
          "description": "Episode description",
          "vid": "video-id-1",
          "poster_url": "https://cdn.example.com/episode-1.jpg"
        }
      }
    ]
  }
}
```

`preload_episode` 的意义是：广场拿到列表后可以立即预热首集，不必再等待详情请求。

### 8.2 剧目详情接口

详情接口返回完整且有序的剧集列表：

```json
{
  "data": {
    "drama": {
      "drama_id": "drama-1001",
      "title": "Example Drama",
      "subtitle": "Example subtitle",
      "category": "Popular",
      "cover_url": "https://cdn.example.com/drama-1001.jpg",
      "episode_count": 60,
      "episodes": [
        {
          "episode_id": "episode-1001-1",
          "album_id": "album-1001",
          "episode_number": 1,
          "title": "Episode 1",
          "description": "Episode description",
          "vid": "video-id-1",
          "poster_url": "https://cdn.example.com/episode-1.jpg"
        }
      ]
    }
  }
}
```

### 8.3 播放身份

每一集至少需要：

```ts
interface EpisodePlaybackSource {
  vid: string;
  albumId?: string;
  episodeId: string;
  playAuthToken?: string;
  poster?: string;
}
```

当前 Minis 环境可以根据审核通过的 `vid + albumId + episodeId` 获取视频。某些接入模式或
旧运行时仍需要临时 `playAuthToken`，此时插件才会增加：

```ts
getVideoByToken: {
  playAuthToken,
  needPoster: true,
}
```

Token 应由可信服务端下发，不应长期写死在前端仓库。

### 8.4 数据适配层

服务端字段保持 `snake_case`，进入前端领域模型时统一转换：

```ts
export function mapEpisode(dto: EpisodeDTO): EpisodeSource {
  return {
    id: dto.episode_id,
    albumId: dto.album_id,
    episodeId: dto.episode_id,
    episodeNumber: dto.episode_number,
    vid: dto.vid,
    playAuthToken: dto.play_auth_token,
    poster: dto.poster_url,
    title: dto.title,
    description: dto.description,
  };
}
```

不要在页面、Player 配置和预加载代码中分别重复字段转换。

## 9. 关闭 Mock 并接入真实 API

本地 Demo 默认：

```ts
export const MOCK_API_ENABLED = true;
```

正式接入时：

1. 把 `MOCK_API_ENABLED` 改为 `false`。
2. 将 `API_BASE_URL` 换成业务 API 地址或环境变量。
3. 保证 List/Detail 返回格式与 `src/api/types.ts` 一致。
4. 删除或保留 `mock-data.ts` 仅用于开发和回归测试。

Mock 返回没有人为延迟，不会为了演示而 sleep。

生产工程建议把配置改为环境变量，例如：

```ts
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
```

不要把正式接口密钥、内部 Header 或播放凭据打进 Web 静态包。

## 10. Player 接入

### 10.1 提前准备

在 React 首次渲染前启动 Player 构造器解析和预加载模块准备：

```ts
import { prepareMinisDramaPreload } from './plugins/minis-player';

void prepareMinisDramaPreload();
createRoot(document.getElementById('root')!).render(<App />);
```

这个调用是 fire-and-forget：

- 不阻塞 React 首屏。
- 失败时只记录 warning。
- 后续创建 Player 仍会再次正常解析 SDK。

### 10.2 创建第一个 Player

准备一个不会在普通 React render 中被替换的容器：

```html
<div id="player-root"></div>
```

创建 Player：

```ts
import { createMinisDramaPlayer } from './plugins/minis-player';

const root = document.getElementById('player-root')!;

const { Player, player } = await createMinisDramaPlayer(
  root,
  drama,
  firstEpisode,
);
```

`createMinisDramaPlayer()` 内部会：

1. 复用缓存的 Player 构造器。
2. 生成统一播放身份。
3. 配置 autoplay、MSE、重试、进度条、海报和画面适配。
4. 创建一个 Player 实例。

### 10.3 默认 Player 配置

当前默认策略：

| 配置 | 值 | 目的 |
| --- | --- | --- |
| `autoplay` | `true` | 尽快开始播放 |
| `muted` | Minis 容器中为 `false` | 使用 `TTMinis.isMinisRuntime` 检测容器并默认有声播放 |
| `enableDegradeMuteAutoplay` | `true` | 有声自动播放失败时降级静音播放 |
| `enableMp4MSE` | `true` | 使用 MP4 MSE 和预加载数据 |
| `retryCount` | `3` | 提高瞬时网络错误恢复能力 |
| `defaultDefinition` | `720p` | 与预加载定义保持一致 |
| `videoFillMode` | `contain` | 不裁切横屏或竖屏视频 |
| `adaptRange` | `15–40s` | 控制 Range 缓冲区间 |
| `controls.mode` | `bottom` | 使用底部控制条 |
| `poster.hideCanplay` | `true` | 可播放后隐藏海报 |

业务可以修改 `src/plugins/minis-player/config.ts` 和
`src/plugins/minis-player/playback-config.ts`，但不要让播放与预加载的清晰度配置分叉。

容器判断必须使用 SDK 提供的 `TTMinis.isMinisRuntime`。不能仅根据
`window.TTMinis` 是否存在判断，因为普通浏览器加载 Script 后同样会存在该对象；
也不要自行匹配 User-Agent。Minis 容器内显式配置 `muted: false`，普通浏览器则
不写入 `muted`，继续交给标准自动播放及静音降级策略处理。

### 10.4 Player 事件

不要硬编码某个 SDK 版本的事件字符串，使用：

```ts
import { playerEvent } from './plugins/minis-player';

player.on?.(playerEvent(Player, 'PLAYING', 'playing'), () => {
  // 首帧已开始展示
});
```

推荐处理：

| 事件 | 用途 |
| --- | --- |
| `READY` | Player 核心准备完成 |
| `LOAD_START` | 媒体开始加载，不代表已看到首帧 |
| `PLAYING` | 开始出画面；可完成 MANUAL→AUTO 交接 |
| `TIME_UPDATE` | 播放进度和业务埋点 |
| `SEEKING/SEEKED` | 进度拖动 UI |
| `ENDED` | 自动下一集 |
| `ERROR` | 错误提示、重试和上报 |
| `PRELOAD_INFO` | 预加载命中统计 |

## 11. 切集：必须使用 `playNext()`

普通切集不要销毁旧 Player，也不要重新 `new Player()`。

```ts
import { playNextEpisode } from './plugins/minis-player';

const success = await playNextEpisode(
  player,
  root,
  drama,
  nextEpisode,
);
```

Demo 的事务顺序：

```mermaid
sequenceDiagram
    participant UI as Swiper/选集 UI
    participant Hook as useMinisPlayer
    participant Player as Minis Player

    UI->>Hook: requestEpisode(target)
    Hook->>Player: pause()
    Hook->>Player: playNext(config, true)
    alt playNext 成功
        Player-->>Hook: resolve
        Hook-->>UI: 提交 episodeIndex
    else playNext 失败
        Player-->>Hook: reject
        Hook-->>UI: 保留当前 episodeIndex
        Hook->>Player: 恢复当前播放
    end
```

关键要求：

- 同一时刻只能有一个切集事务。
- UI 集数只能在 `playNext()` 成功后更新。
- 滑动、选集和自动下一集共用相同事务。
- 切集时将倍速恢复为 1。
- 切集失败不能留下“UI 是第 2 集、Player 还在第 1 集”的状态。

## 12. 广场 MANUAL 预热

### 12.1 为什么在广场预热

预热必须发生在用户浏览广场的空闲时间，而不是点击播放页后才注册。

列表返回后立即调用：

```ts
import { preloadDramaEpisode } from './plugins/minis-player';

if (drama.preloadEpisode) {
  void preloadDramaEpisode(drama, drama.preloadEpisode);
}
```

默认只预热一个最可能点击的入口，避免多个视频争抢弱网带宽。

### 12.2 用户意图更新

桌面端或键盘访问可以在 hover/focus 时替换 MANUAL 目标：

```tsx
<button
  onPointerEnter={() => preloadDramaEpisode(drama, drama.preloadEpisode!)}
  onFocus={() => preloadDramaEpisode(drama, drama.preloadEpisode!)}
>
  {drama.title}
</button>
```

移动端 focus 到点击之间的窗口很短，因此不要依赖点击时才预热。真正重要的是列表返回后
提前预热默认目标。

### 12.3 MANUAL 场景

默认配置：

```ts
manualPreload: {
  preloadTime: 5,
}
```

`preloadDramaEpisode()` 会：

1. 确保 `Player.prepare()` 已启动。
2. 设置 `PRELOAD_SCENE.manual`。
3. 清理旧 MANUAL 列表和任务。
4. 注册一个新的目标集。
5. 捕获错误，不阻塞正常页面和播放。

## 13. 播放页 AUTO 预加载

### 13.1 交接顺序

```mermaid
sequenceDiagram
    participant Square as 广场页
    participant Preloader as Player Preloader
    participant Theater as 播放页
    participant Player as Minis Player

    Square->>Preloader: MANUAL preload(entry episode)
    Square->>Theater: 用户进入播放页
    Theater->>Player: new Player(entry episode)
    Player-->>Theater: PLAYING / 首帧
    Theater->>Preloader: 清理 MANUAL
    Theater->>Preloader: AUTO list(all episodes)
    Preloader-->>Player: prev 1 / next 2
```

如果是直接打开 Theater，没有广场 MANUAL 任务，则在 Player 创建前配置完整 AUTO 列表。

### 13.2 AUTO 配置

默认：

```ts
autoPreload: {
  prevCount: 1,
  nextCount: 2,
  preloadTime: 5,
}
```

调用：

```ts
await setupDramaAutoPreload(drama, drama.episodes);
```

要求：

- 传入完整、顺序正确的剧集列表。
- 不要每次 `TIME_UPDATE` 重复注册完整列表。
- MANUAL 预热入口必须等到 `PLAYING` 后再清理。
- 交接函数必须幂等。

完整 React 实现参考 `src/hooks/useMinisPlayer.ts`。

## 14. 媒体信息缓存

默认使用内存缓存：

```ts
mediaInfoCache: {
  enable: true,
  cacheType: 'memory',
  expireTime: 30 * 60 * 1000,
  maxEntries: 100,
}
```

它可以减少相同剧集信息的重复请求。注意：

- 缓存不是永久存储。
- 播放与预加载定义必须一致。
- 真实收益应通过 getDramaInfo 耗时和 FVT 数据验证。
- 不要把带敏感凭据的完整响应写入不受控的本地长期存储。

## 15. WebView 生命周期

播放页必须同时考虑：

- `visibilitychange`
- `pagehide`
- `pageshow`

进入后台：

1. 记录当前是否正在播放。
2. 把倍速恢复为 1。
3. 暂停唯一 Player。

回到前台：

- 只有后台前确实在播放时才尝试恢复。
- 用户手动暂停的视频不能被前台事件强制播放。
- `play()` 失败时捕获自动播放限制，不让 Promise rejection 泄漏。

完整实现参考 `useMinisPlayer.ts`。

## 16. 播放结束自动下一集

监听 `ENDED` 后，不应另外实现一套切集逻辑：

```ts
if (currentIndex < episodes.length - 1) {
  await selectEpisode(currentIndex + 1);
} else {
  showDramaEndedToast();
}
```

`selectEpisode()` 应继续复用相同的切集事务和 `playNext()`。

## 17. 倍速

Minis Player 的倍速最终设置在底层媒体实例：

```ts
const playerCore = player.player;

if (playerCore?.media) {
  playerCore.media.playbackRate = 2;
}
if (playerCore) {
  playerCore.playbackRate = 2;
}
```

Demo 的长按逻辑：

- 长按 420ms：临时进入 2 倍速。
- 松手：恢复进入倍速前的速率。
- 下滑到阈值后松手：锁定或解除 2 倍速。
- 切集、进入后台、退出页面：恢复为 1 倍速。

420ms 是长按手势判定，不是播放等待。

## 18. 画面填充与海报

当前使用：

```ts
videoFillMode: 'contain'
```

`contain` 的行为：

- 完整显示视频。
- 不裁切竖屏或横屏内容。
- 视频比例与容器不一致时允许出现黑边。

如果改为 `cover`：

- 可以铺满容器。
- 会裁切视频上下或左右内容。
- 不适合字幕、人物或关键信息靠近画面边缘的短剧。

海报和视频应使用相同的适配策略，避免切集时海报先放大再缩小。

广场封面容器的 `aspect-ratio: 2 / 3` 表示封面卡片宽高比，不等于视频播放比例。

## 19. 控制条与页面布局

推荐结构：

```text
theater-page
├── theater-stage       # 剩余可播放高度
│   └── player-root     # xgplayer 和 controls
└── theater-footer      # 选集入口 + safe area
```

选集入口放在 footer，视频 stage 使用剩余高度。这样可以避免：

- 控制条被 footer 或渐变遮挡。
- xg-controls 跑到整个屏幕最底部。
- 拖动进度条时命中页面滑动手势。

页面手势遇到以下元素时应让 Player 优先处理：

```ts
event.target.closest('.xgplayer-progress, .xgplayer-controls')
```

进度拖动状态优先使用 Player 配置的 `progress.onMoveStart/onMove/onMoveEnd`。为兼容部分
Minis Player 版本，还应在 progress 插件完成初始化后通过
`useHooks('dragstart' | 'drag' | 'dragend')` 绑定同一组回调；hook 返回 `true`，保留
Player 默认 seek 行为。拖动开始进入清屏态，拖动结束恢复业务浮层。

渐变层必须 `pointer-events: none`，并把 controls 的层级放在业务渐变和文案之上。

## 20. 自动播放与 Unmute

浏览器和 WebView 可能禁止有声自动播放。当前配置：

```ts
enableDegradeMuteAutoplay: true
```

当有声自动播放失败时：

1. Player 降级为静音自动播放。
2. 显示一个 SDK 提供的 unmute 提示。
3. 用户点击后恢复声音。

不要再叠加第二个业务 unmute 浮层，否则会出现两个提示。

## 21. 首帧优化清单

### 21.1 前端

- SDK 域名和静态 CDN 使用 `preconnect`/`dns-prefetch`。
- React render 前调用 `prepareMinisDramaPreload()`，但不 await 阻塞页面。
- List API 返回 `preload_episode`。
- 广场列表返回后立即开始 MANUAL 预热。
- 初播、切集、预加载统一播放身份和清晰度。
- 使用一个 Player，切集调用 `playNext()`。
- 开启 MP4 MSE、媒体信息缓存、重试和 Range 自适应。
- Theater 页面拆包，并在广场提前加载其代码 chunk。
- MANUAL 任务在 `PLAYING` 后交给 AUTO。
- 不添加人为 sleep 或“最多等待 N 秒再播放”。

### 21.2 视频与 CDN

- MP4 `moov` metadata 前置。
- 建议从 H.264、720p、30fps 和克制码率开始，根据数据调优。
- 海报尺寸匹配展示区域，避免下载过大的原图。
- CDN 正确支持 Range。
- 播放地址有效期覆盖合理的观看时间。

### 21.3 需要观测的指标

- 点击到 Player 创建。
- Player 创建到 `PLAYING`。
- 播放日志中的真实 `vt`/FVT。
- `PRELOAD_INFO` 和 `preLoadData.hit`。
- getDramaInfo 耗时。
- 视频首请求 TTFB。
- 首帧前重试率。
- 播放失败率。
- 首 10 秒卡顿率。
- 无效 MANUAL 预热流量。

## 22. 上线配置

### 22.1 `minis.config.json`

必须替换：

```json
{
  "dev": {
    "clientKey": "<YOUR_CLIENT_KEY>",
    "name": "<YOUR_APP_NAME>",
    "iconUrl": "<YOUR_ICON_URL>",
    "desc": "<YOUR_DESCRIPTION>",
    "ppLink": "<YOUR_PRIVACY_POLICY_URL>",
    "tosLink": "<YOUR_TERMS_URL>"
  }
}
```

### 22.2 `index.html`

- 使用相同 `clientKey`。
- SDK 地址使用平台允许的生产版本。
- 保留正确的 viewport 和 safe-area 配置。
- 根据生产 CSP 增加 SDK/CDN/API 域名。

### 22.3 服务端

- List API 返回预热入口。
- Detail API 返回完整有序列表。
- Token 由服务端安全签发。
- 地址有效期和刷新策略满足连续观看。
- 正式资源已审核并授权给目标 Minis 应用。

## 23. 生产上线检查表

仅替换真实视频资源还不等于完成上线。发布前至少确认：

- [ ] `MOCK_API_ENABLED=false`
- [ ] 真实 List/Detail API 已接入
- [ ] `preload_episode` 可以播放并与详情首集身份一致
- [ ] 所有 `vid/album_id/episode_id` 对应正确
- [ ] Token 模式已在正式环境验证
- [ ] 未包含 PPE Header、内部域名和内部凭据
- [ ] 使用正式 clientKey
- [ ] 使用平台批准的 SDK 地址/版本
- [ ] Icon、隐私政策和服务条款已补齐
- [ ] HTTPS、CORS、CSP、域名白名单配置完成
- [ ] iOS/Android 目标 WebView 验证通过
- [ ] 弱网、切后台、锁屏、来电等场景验证通过
- [ ] 滑动、选集、自然结束均复用 `playNext()`
- [ ] 切集后页面中仍只有一个 `<video>`
- [ ] 暂停后没有其他视频继续出声
- [ ] 预加载命中率和 FVT 已接入监控
- [ ] 播放错误有用户可见的重试或降级方案
- [ ] 自动化冒烟或 E2E 已进入发布门禁

## 24. 验收用例

### 24.1 广场

1. 页面打开后剧集立即排版，无人为 Loading 延迟。
2. 用户未点击时，默认入口的 MANUAL 预加载已注册。
3. Home 可点击，其他底部入口保持禁用。
4. 海报、标题和进入后的剧目一致。

### 24.2 播放页

1. 首集可以出画面，页面只有一个 `<video>`。
2. 点击视频可以暂停/继续。
3. 暂停后 xgplayer 进度条可见且可拖动。
4. 上下滑动连续多次均可以切集。
5. 切集使用 `playNext()`，Player 实例不重建。
6. 切集失败时 UI 回退到当前集。
7. 第 1 集结束后自动进入第 2 集。
8. 最后一集结束后不越界。
9. 选集面板当前集状态正确。
10. WebView 进入后台没有声音，回前台按原状态恢复。
11. 横屏和竖屏视频均完整显示。
12. 只有一个 unmute 提示。

### 24.3 预加载

1. 广场日志先出现单集 MANUAL 列表。
2. MANUAL 入口开始 `PLAYING` 后再切 AUTO。
3. 多集剧目 AUTO 策略拥有前 1、后 2 的配置。
4. 播放与预加载使用相同 definition。
5. 预加载失败不阻止普通播放。

## 25. 常见问题

### 25.1 浏览器打不开 `localhost:5173`

本工程默认端口是 `5177`：

```text
http://localhost:5177/playlet/square
```

先查看终端中 Vite 实际输出的 Local 地址。

### 25.2 `TikTok Minis SDK is unavailable`

检查：

- SDK Script 是否成功加载。
- `TTMinis.init()` 是否执行。
- clientKey 是否正确。
- 是否在 SDK 初始化前调用了业务 Player。
- CSP 是否拦截 SDK。

### 25.3 `TTMinis.getPlayer() returned no player constructor`

检查 channel、SDK 版本和目标运行环境。Demo 默认：

```ts
TTMinis.getPlayer('byteplus');
```

### 25.4 `Video URL is empty`

通常不是 CSS 或 Player 容器问题。检查：

- `vid/album_id/episode_id` 是否属于同一集。
- 资源是否已审核和授权给当前应用。
- 正式环境是否需要 `playAuthToken`。
- Token 是否过期。
- SDK 地址、clientKey 和目标环境是否匹配。

不要用 fallback 测试 URL 隐藏真实鉴权问题。

### 25.5 切到某一集仍然播放旧测试视频

检查该集是否仍使用 Mock 身份，或者错误路径是否回退到演示 URL。最佳实践是：

- 播放身份无效时明确报错。
- 不偷偷播放无关 fallback 视频。
- UI 只有在 `playNext()` 成功后才切集。

### 25.6 竖屏视频出现黑边

这是 `contain` 保证不裁切的正常结果。如果业务一定要铺满，可以改为 `cover`，但必须接受
内容被裁切，并对字幕安全区做专项验收。

### 25.7 控制条被渐变或选集入口遮挡

检查：

- footer 是否独立占据底部高度。
- stage 是否只使用剩余高度。
- `.theater-gradient` 是否 `pointer-events: none`。
- `.xgplayer-controls` 的 z-index 是否高于业务遮罩。

### 25.8 切到第二集后还有别的视频播放

正常架构中应只有一个 Player 和一个 `<video>`。检查：

- 是否在每个 slide 中分别创建了 Player。
- 切集是否错误地重新 `new Player()`。
- 页面卸载时是否调用 `destroy()`。
- 后台和非激活页面是否调用 `pause()`。

### 25.9 为什么没有清晰度和 SDK 长按面板

当前 Minis 运行时没有完整开放这些面板，Demo 不伪造 SDK 能力。长按 2 倍速是业务层手势，
不是 SDK 的清晰度/更多设置面板。

## 26. 推荐的客户改造边界

| 可以直接改 | 建议谨慎改 | 不建议改 |
| --- | --- | --- |
| 页面 UI、颜色、图标、文案 | 预热候选数量 | SDK 获取方式 |
| List/Detail API | AUTO 前后集数量 | 初播/切集/预加载身份一致性 |
| 海报和剧集信息 | definition 和码率 | 单 Player + `playNext()` |
| 埋点 transport | 缓存类型和过期时间 | WebView 后台暂停 |
| 错误提示和重试 UI | fill mode | 切集事务提交顺序 |

## 27. 参考入口

- 完整应用说明：`README.md`
- Player 插件说明：`src/plugins/minis-player/README.md`
- 完整 React 生命周期：`src/hooks/useMinisPlayer.ts`
- 广场预热：`src/pages/SquarePage.tsx`
- 播放页 UI：`src/pages/TheaterPage.tsx`
- 工程对比与首帧分析：`docs/vod-h5-demo-comparison-report.md`
