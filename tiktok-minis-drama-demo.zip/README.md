# TikTok Minis Drama Demo

A mobile-first React demo with a drama square and an immersive episode player. The player is loaded only from the TikTok Minis SDK script and resolved with `window.TTMinis.getPlayer()`; `@volcengine/veplayer` is intentionally not installed.

## Documentation

- [Best-practice integration guide](./docs/best-practice-integration-guide.md)
- [Comparison with vod-h5-demo](./docs/vod-h5-demo-comparison-report.md)
- [Portable Minis Player plugin](./src/plugins/minis-player/README.md)

## Run

```bash
npm install
npm run dev
```

Open `http://localhost:5177/playlet/square`.

For Minis container debugging, keep the Vite server running and start the
Minis debugger in a second terminal:

```bash
npm run minis:debug
```

`minis.config.json` uses the same `5177` development port as Vite. Before
integrating another Minis application, replace `dev.clientKey` there and the
`clientKey` passed to `TTMinis.init()` in `index.html` with the same value.

## Build for Minis

```bash
npm run build
npm run check:minis:output
```

`npm run build` first performs the TypeScript/Vite web build, then runs the
TikTok Minis CLI. The final `dist/` contains the web assets together with
`minis.config.json` and `minis.manifest.json`.

Use `npm run build:web` when only a normal web build is needed. The additional
Minis commands mirror the reference SDK project:

- `npm run build:minis`
- `npm run build:minis:sandbox`
- `npm run check:minis:local`
- `npm run check:minis:output`

## Replace playback data

The demo uses an API-shaped data layer under `src/api/`. During local
development, `MOCK_API_ENABLED` in `src/api/client.ts` intercepts the list and
detail calls and returns `src/api/mock-data.ts`.

Each raw episode carries `album_id`, `episode_id`, `vid`, and optionally
`play_auth_token`. Set `MOCK_API_ENABLED` to `false` and replace `API_BASE_URL`
when a real backend is available. `src/api/adapters.ts` is the only place that
maps backend snake_case fields to the app model.

The checked-in fixtures contain two playable dramas:

- `forbidden-love`: three episodes in album `7665126538443196436`.
- `drama-three`: three episodes in album `7667061213232384021`.

For the fastest square-to-theater first frame, each list item should include
one optional `preload_episode` carrying the same playback identity fields as an
episode detail. This avoids a list → detail waterfall before discovery-page
preload. The demo keeps a detail-request fallback so an older backend contract
still works; it does not duplicate the complete episode list in the discovery
response.

The player hook creates one instance for the theater and switches episodes with
`playNext()`; it destroys the instance only when the theater unmounts or the
drama changes.

Episode changes are transactional: the card UI commits only after `playNext()`
succeeds and rolls back on failure. The `ended` event advances to the next
episode through the same transaction. WebView `pagehide/pageshow` and
`visibilitychange` pause and conditionally resume only the active Player.

Replace the client key in `index.html` when using your own TikTok Minis application.

## Playback flow

The API identity fields `album_id` and `episode_id` should be mapped at the data boundary to `albumId` and `episodeId`. All playback paths then share `buildAuthorizedPlaybackConfig()`:

```ts
const config = {
  vid: episode.vid,
  albumId: episode.albumId,
  episodeId: episode.episodeId,
  ...(episode.playAuthToken
    ? {
        getVideoByToken: {
          playAuthToken: episode.playAuthToken,
          needPoster: true,
        },
      }
    : {}),
};
```

`getVideoByToken` is included only when `playAuthToken` is non-empty. Current
TikTok clients can resolve reviewed drama media from `albumId`, `episodeId` and
`vid`; older clients still require the temporary token.

The first episode uses `new Player(config)`. Every later episode reuses that
instance with `await player.playNext(nextConfig, true)`. The square uses MANUAL
scene preload immediately after the discovery list arrives and may retarget it
on card hover/focus intent. Player creation never waits for a new preload task:
an existing cache is reused when available, otherwise normal playback starts.
The theater switches to AUTO scene preload only after a MANUAL-warmed entry
episode emits its first-frame event. At that point it clears the old MANUAL
list/task and lets the Player own one previous and two next episodes, matching
the documented handoff.

Before React renders, the plugin resolves `TTMinis.getPlayer()`, enables the
in-memory media-info cache and prepares the preload strategy. Player and
preload configurations read the same definition from
`src/plugins/minis-player/config.ts`; playback enables MP4 MSE, three retries
and byte-range adaptation. The plugin uses the documented Player returned by
`TTMinis.getPlayer()` and does not inspect private runtime flags.

The theater page is a lazy code chunk. The square warms that chunk
asynchronously alongside the first media preload, keeping theater-only gesture
code out of the critical discovery-page JavaScript without paying the import
cost after a card click.

## First-frame integration checklist

- Put MP4 `moov` metadata at the front during transcoding. A practical starting
  ladder for short drama is H.264, 720p, 30 fps, with a restrained bitrate;
  tune it against visual quality and the target network.
- Keep the Minis SDK and static CDN origins in `preconnect`/`dns-prefetch`, as
  shown in `index.html`.
- Return `preload_episode` in the discovery list and call MANUAL preload as soon
  as the list arrives. Use user intent to update the target before navigation.
- Call `Player.prepare({ strategies: { preload: true } })` and keep
  `enableMp4MSE: true`. Use the same `vid`, `albumId`, `episodeId`, token and
  definition across preload, initial creation and `playNext()`.
- Reuse one Player instance with `playNext()`; do not destroy/recreate it for
  normal episode changes. After the first frame, clear the old MANUAL task and
  configure the complete ordered episode list once for AUTO neighbor preload.
- Treat preload as an optimization: start it early, catch failures and preserve
  normal playback fallback without delaying Player creation. Never put internal
  PPE headers or environment credentials in the reusable client plugin.
- In production telemetry, record preload hit/miss from `PRELOAD_INFO`
  (`preLoadData.hit`) together with create-player-to-playing first-frame time,
  episode identity, network type and error code. The demo deliberately leaves
  transport/reporting to the integrator instead of shipping a vendor-specific
  analytics endpoint.

## Copy the player plugin

`src/plugins/minis-player/` has no React or demo-local dependencies. Copy the
whole directory into another TypeScript application and import through its
`index.ts`:

```ts
import {
  createMinisDramaPlayer,
  playNextEpisode,
  preloadDramaEpisode,
} from './minis-player';

const { player } = await createMinisDramaPlayer(container, drama, firstEpisode);
await playNextEpisode(player, container, drama, nextEpisode);

// Optional discovery-page preload:
await preloadDramaEpisode(drama, firstEpisode);

// Page teardown:
player.destroy?.();
```

## Architecture

- `src/plugins/minis-player/`: portable player plugin, split into customer policy, SDK access, types, playback config, playback operations and preload.
- `src/router/lazy-pages.ts`: theater code splitting and discovery-page warm import.
- `src/hooks/useMinisPlayer.ts`: single-instance lifecycle, transactional switching, ended handling, WebView foreground/background behavior and cleanup.
- `src/api/types.ts`: raw backend response contracts using snake_case fields.
- `src/api/client.ts`: list/detail API calls and the local Mock interception switch.
- `src/api/mock-data.ts`: replaceable API-shaped test fixtures.
- `src/api/adapters.ts`: backend DTO to UI/player domain mapping.
- `src/hooks/useDramaApi.ts`: asynchronous list/detail loading for React pages.
- `src/pages/SquarePage.tsx`: discovery page and category layout.
- `src/pages/TheaterPage.tsx`: immersive player, vertical swipe, keyboard navigation and episode sheet.

Routes intentionally follow `vod-h5-demo`: `/playlet/square` and `/playlet/theater?id=<dramaId>`.
